#include "hash.h"
#include <vector>
#include <string>
#include <iostream>

int main(){

    hashTable *dict = new hashTable();

    for(char i = 0; i < 1200; i++){
        dict->insert("sugoma"+std::to_string(i));
        //std::cout << "sugoma"+std::to_string(i);
    }    

    //contains check
    std::cout << std::endl << dict->contains("sugoma2");
    std::cout << std::endl << dict->contains("sugoma269");



    delete dict;

    return 0;
}